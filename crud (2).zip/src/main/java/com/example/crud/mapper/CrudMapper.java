package com.example.crud.mapper;

import com.example.crud.dto.CrudDto;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface CrudMapper {
    @Insert("insert into mem values(null, #{mUid}, #{mPWD}, #{mName})")
    void setSave(CrudDto crudDto);

    @Select("select * from mem ${searchQuery} order by mID desc")
    List<CrudDto> getMem(String searchQuery);

    @Select("select count(*) from mem ${searchQuery}")
    int getMemCount(String searchQuery);

    @Select("select * from mem where mID = #{mID}")
    CrudDto getEdit(int mID);

    @Update("update mem set mUid=#{mUid}, mPWD = #{mPWD}, mName = #{mName} where mID = #{mID}")
    void setEdit(CrudDto crudDto);

    @Delete("DELETE FROM mem WHERE mId = #{mID}")
    void setDelete(int mID);
}
