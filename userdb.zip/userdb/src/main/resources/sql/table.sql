use userdb;

create table members(
id int not null auto_increment,
Email varchar(50),
FirstName varchar(20),
LastName varchar(20),
Password varchar(50),
Enabled varchar(5),
primary key(id)
);


