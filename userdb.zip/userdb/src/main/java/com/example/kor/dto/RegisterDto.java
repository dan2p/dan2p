package com.example.kor.dto;

import lombok.Data;

@Data
public class RegisterDto {
    private int id;
    private String Email;
    private String FirstName;
    private String LastName;
    private String Password;
    private String Enabled;
}
