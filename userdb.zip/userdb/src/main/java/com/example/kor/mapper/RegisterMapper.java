package com.example.kor.mapper;


import com.example.kor.dto.RegisterDto;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import java.util.List;

@Mapper
public interface RegisterMapper {

    @Insert("INSERT INTO member VALUES(NULL, #{Email}, #{FirstName}, #{LastName} , #{Password}, #{Enabled} )" )
    void getRegister(RegisterDto registerDto);

    @Select("SELECT * FROM member " +
            "WHERE userid = #{Email} AND passwd = #{Password}")
    RegisterDto checkLogin(RegisterDto registerDto);

    @Select("SELECT * FROM member ORDER BY id DESC")
    List<RegisterDto> getMemberAll();

    @Select("SELECT * FROM member WHERE id = #{id}")
    RegisterDto getMemberOne(int id);

    @Update("UPDATE member SET " +
            "Email = #{Email}, FirstName = #{FirstName}, " +
            "LastName = #{LastName}, Password = #{Password}, Enabled = #{Enabled} WHERE id = #{id}")
    void setUpdate(RegisterDto registerDto);

}
