package com.example.kor.service;

import com.example.kor.dto.ArticleDto;
import com.example.kor.mapper.ConfigMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class ArticleSrv {

    @Autowired
    private ConfigMapper configMapper;

    public List<ArticleDto> getList(
            String code, String searchType, String words) {

        String searchQuery = "";

        if( searchType.equals("subject") || searchType.equals("writer") ) {
            searchQuery = "WHERE "+searchType+" = '"+words+"'";

        }else if( searchType.equals("content") ) {
            searchQuery = "WHERE content LIKE '%"+words+"%'";

        }else {
            searchQuery = "";
        }

        Map<String, Object> map = new HashMap<>();
        map.put("code", code);
        map.put("searchQuery", searchQuery);

        return configMapper.getList(map);
    }

}
