use cruddb;

create table mem(
mID int not null auto_increment,
mUid varchar(20),
mPWD varchar(20),
mName varchar(20),
primary key(mID)
);

